#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_corpus.py — Scarica SOLO documenti AI in inglese (EN/ENG) da Internet Archive
e salva in corpus/ file .txt contenenti SOLO:
  Author: <Autore/i>

  <Abstract>

Se non trova un abstract affidabile, salta l'item.
Il titolo NON viene scritto nel file; rimane soltanto nel nome del file.

Esempi:
  python fetch_corpus.py --min 100
  python fetch_corpus.py --min 100 --sleep 0.5
"""

from __future__ import annotations
import argparse, json, re, time, html
from pathlib import Path
from typing import Dict, Any, List, Optional
import requests

ADV_SEARCH = "https://archive.org/advancedsearch.php"
META_API   = "https://archive.org/metadata/{identifier}"
UA         = "LorenzoCozzolino-IR-Homework/AI-Abstracts/1.1"

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": UA, "Accept": "application/json"})

# Termini AI per la ricerca (puoi ampliarli)
AI_TERMS = [
    "artificial intelligence",
    "machine learning",
    "deep learning",
    "neural network",
    "computer vision",
    "natural language processing",
    "pattern recognition",
    "data mining"
]

# Regex utili
TAG_RE   = re.compile(r"<[^>]+>")
WS_RE    = re.compile(r"[ \t]+")
NL3_RE   = re.compile(r"\n{3,}")

# Estrazione "Abstract" dal testo grezzo: cerca sezione iniziale Abstract
ABSTRACT_RE = re.compile(
    r"(?is)^\s*abstract\s*[:\.\-–]?\s*\n?(.*?)(?:\n\s*\n|^\s*(?:introduction|1\s+introduction|chapter\s+1)\b)",
    re.MULTILINE
)

def strip_html(s: str) -> str:
    s = html.unescape(s)
    s = TAG_RE.sub(" ", s)
    s = WS_RE.sub(" ", s)
    return s.replace("\r", "").strip()

def normalize_text(s: str) -> str:
    s = s.replace("\r", "")
    s = NL3_RE.sub("\n\n", s)
    return s.strip()

def build_ai_query() -> str:
    # Solo documenti testuali in lingua inglese, con termini AI
    terms_or = " OR ".join(f'"{t}"' for t in AI_TERMS)
    lang_or  = "language:(eng OR en OR english)"
    base = f'mediatype:(texts) AND ({lang_or}) AND ({terms_or})'
    base += ' AND format:("Text" OR "TXT" OR "Text PDF" OR "text")'
    return base

def ia_search(query: str, page: int=1, rows: int=100) -> Dict[str, Any]:
    params = {
        "q": query,
        "fl[]": ["identifier", "title", "language", "downloads"],
        "sort[]": "downloads desc",
        "rows": rows,
        "page": page,
        "output": "json"
    }
    r = SESSION.get(ADV_SEARCH, params=params, timeout=30)
    r.raise_for_status()
    return r.json()

def ia_metadata(identifier: str) -> Dict[str, Any]:
    url = META_API.format(identifier=identifier)
    r = SESSION.get(url, timeout=30)
    r.raise_for_status()
    return r.json()

def best_authors_from_meta(meta: Dict[str, Any]) -> Optional[str]:
    """
    Estrae gli autori dai metadati:
      - campi comuni: 'creator', 'author', 'authors'
      - possono essere stringhe o liste
    Restituisce una stringa tipo "Name1; Name2; Name3" oppure None.
    """
    m = meta.get("metadata", {}) or {}
    for key in ("creator", "author", "authors"):
        if key in m and m[key]:
            v = m[key]
            if isinstance(v, list):
                parts = [strip_html(str(x)) for x in v if str(x).strip()]
            else:
                # divide su separatori comuni
                raw = strip_html(str(v))
                parts = [p.strip() for p in re.split(r"[;,/]| and ", raw) if p.strip()]
            # filtra robe non sensate/URL
            parts = [p for p in parts if len(p) <= 120 and "http" not in p.lower()]
            if parts:
                return "; ".join(parts[:8])  # limita a 8 nomi
    return None

def best_abstract_from_meta(meta: Dict[str, Any]) -> Optional[str]:
    """
    Cerca abstract nei metadati ('abstract', 'description').
    Ritorna una stringa pulita oppure None se non credibile.
    """
    m = meta.get("metadata", {}) or {}
    cand = None
    for key in ("abstract", "description"):
        if key in m and m[key]:
            v = m[key]
            if isinstance(v, list):
                # prendi il più lungo ragionevole
                v = max((str(x) for x in v), key=lambda t: len(str(t)), default="")
            cand = strip_html(str(v))
            break
    if not cand:
        return None
    # euristiche di plausibilità
    if len(cand) < 80:      # troppo corto
        return None
    if len(cand) > 8000:    # troppo lungo per un abstract
        return None
    return cand

def fetch_first_small_txt(meta: Dict[str, Any], max_size_bytes: int = 1_500_000) -> Optional[str]:
    """
    Scarica un .txt piccolo dall'item (se presente) e lo restituisce come testo.
    """
    identifier = meta.get("metadata", {}).get("identifier", "")
    files = meta.get("files", []) or []
    base_url = f"https://archive.org/download/{identifier}"
    for f in files:
        name = f.get("name", "")
        if not name.lower().endswith(".txt"):
            continue
        size = int(f.get("size") or 0)
        if not (0 < size <= max_size_bytes):
            continue
        url = f"{base_url}/{name}"
        try:
            r = SESSION.get(url, timeout=60)
            r.raise_for_status()
            try:
                return r.content.decode("utf-8")
            except UnicodeDecodeError:
                return r.content.decode("latin-1", errors="ignore")
        except Exception:
            continue
    return None

def extract_abstract_from_text(fulltext: str) -> Optional[str]:
    """
    Prova a estrarre la sezione Abstract dal testo completo.
    """
    if not fulltext:
        return None
    text = normalize_text(fulltext)
    m = ABSTRACT_RE.search(text)
    if not m:
        return None
    abstract = m.group(1).strip()
    if len(abstract) < 80 or len(abstract) > 8000:
        return None
    return abstract

def sanitize_filename(name: str) -> str:
    name = re.sub(r"[^\w\-.]+", "_", name, flags=re.UNICODE)
    return name.strip("_") or "file"

def save_author_and_abstract(outdir: Path, title: str, authors: Optional[str], abstract: str, identifier: str) -> Path:
    """
    Salva SOLO:
      Author: <Autore/i>

      <Abstract>
    Il titolo NON viene scritto, resta soltanto nel nome del file.
    """
    slug = sanitize_filename((title or identifier).lower())[:80]
    fname = f"{slug}--{sanitize_filename(identifier)}.txt"
    dest = outdir / fname

    author_line = f"Author: {authors if authors else 'Unknown'}"
    content = f"{author_line}\n\n{abstract.strip()}\n"
    dest.write_text(content, encoding="utf-8")
    return dest

def main():
    ap = argparse.ArgumentParser(description="Scarica TITLE-as-filename + (Author line + Abstract) da item AI EN in Internet Archive.")
    ap.add_argument("--min", type=int, default=100, help="Minimo file da creare (default 100)")
    ap.add_argument("--out", type=Path, default=Path("corpus"), help="Cartella output (default ./corpus)")
    ap.add_argument("--sleep", type=float, default=1.0, help="Pausa tra item (s)")
    ap.add_argument("--pages", type=int, default=60, help="Pagine max di ricerca (100 item/pagina)")
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    total = 0
    query = build_ai_query()
    report = {"query": query, "downloaded": []}
    print(f"[INFO] Query: {query}")

    for page in range(1, args.pages + 1):
        try:
            data = ia_search(query, page=page, rows=100)
        except Exception as e:
            print(f"[WARN] Ricerca pagina {page} errore: {e}")
            break

        docs = data.get("response", {}).get("docs", []) or []
        if not docs:
            break

        for doc in docs:
            ident = doc.get("identifier")
            if not ident:
                continue

            # Metadati completi
            try:
                meta = ia_metadata(ident)
            except Exception:
                time.sleep(args.sleep)
                continue

            md  = meta.get("metadata", {}) or {}
            ttl = md.get("title") or doc.get("title") or ident
            title = strip_html(str(ttl)) or ident

            # Autori
            authors = best_authors_from_meta(meta)

            # Abstract (meta → fallback txt)
            abstract = best_abstract_from_meta(meta)
            if not abstract:
                fulltext = fetch_first_small_txt(meta, max_size_bytes=1_500_000)
                if fulltext:
                    abstract = extract_abstract_from_text(fulltext)

            if not abstract:
                # se non troviamo un abstract decente, saltiamo
                continue

            dest = save_author_and_abstract(args.out, title, authors, abstract, ident)
            total += 1
            report["downloaded"].append({
                "identifier": ident,
                "title": title,
                "authors": authors or "Unknown",
                "path": str(dest),
                "bytes": len((f'Author: {authors or "Unknown"}\n\n' + abstract).encode("utf-8"))
            })
            print(f"[OK] {dest.name}  total={total}")

            if total >= args.min:
                break

            time.sleep(args.sleep)

        if total >= args.min:
            break

    with open(args.out / "_fetch_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print(f"\n Creati {total} file (Author + Abstract EN) in {args.out.resolve()}")
    if total < args.min:
        print("[NOTE] Meno del minimo richiesto: aumenta --pages o riduci --sleep.")

if __name__ == "__main__":
    main()