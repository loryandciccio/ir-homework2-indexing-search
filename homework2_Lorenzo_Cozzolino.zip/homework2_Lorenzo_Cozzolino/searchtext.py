#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
searchtext.py — Homework 2 (IR) in Python
Indicizza file .txt e permette ricerche su:
- nome (campo: name)
- contenuto (campo: content)

Dipendenze: whoosh
  pip install whoosh

Esempi:
  python searchtext.py index --docs ./corpus --index ./indexdir
  python searchtext.py search --index ./indexdir
"""
from __future__ import annotations
import argparse, json, os, sys, time
from pathlib import Path
from typing import Iterable, Tuple

from whoosh import index
from whoosh.fields import Schema, TEXT, ID, STORED
from whoosh.analysis import RegexTokenizer, LowercaseFilter, CharsetFilter, StemmingAnalyzer, StopFilter
from whoosh.support.charset import accent_map
from whoosh.qparser import QueryParser, OrGroup
from whoosh.highlight import ContextFragmenter, UppercaseFormatter


# ---------- SCHEMA & ANALYZER ----------

from whoosh.analysis import RegexTokenizer, LowercaseFilter, CharsetFilter, IntraWordFilter
from whoosh.support.charset import accent_map

def build_schema() -> Schema:
    # separa su tutto ciò che non è lettera o cifra (underscore NON incluso nei token)
    base_tokenizer = RegexTokenizer(r"[A-Za-z0-9]+")
    name_analyzer = (base_tokenizer
                     | IntraWordFilter(mergewords=True, mergenums=True)  # split/merge intelligente (es. mondo2000 -> mondo, 2000, mondo2000)
                     | LowercaseFilter()
                     | CharsetFilter(accent_map))

    content_analyzer = (StemmingAnalyzer("en") | CharsetFilter(accent_map))  # come messo nella patch precedente, niente StopFilter per phrase con stopword

    return Schema(
        path=ID(stored=True, unique=True),
        name=TEXT(stored=True, analyzer=name_analyzer, phrase=True),
        content=TEXT(stored=True, analyzer=content_analyzer, phrase=True),
        size=STORED,
        mtime=STORED
    )


# ---------- INDICIZZAZIONE ----------

def iter_txt_files(root: Path) -> Iterable[Path]:
    """Ritorna tutti i file .txt nella cartella indicata."""
    for p in root.rglob("*.txt"):
        if p.is_file():
            yield p

def index_dir(docs_dir: Path, index_dir: Path) -> Tuple[int, float]:
    """Indicizza tutti i file .txt di docs_dir in index_dir."""
    index_dir.mkdir(parents=True, exist_ok=True)

    if index.exists_in(index_dir):
        ix = index.open_dir(index_dir)
    else:
        ix = index.create_in(index_dir, build_schema())

    writer = ix.writer(limitmb=256, procs=0, multisegment=False)
    start = time.perf_counter()
    count = 0
    for fp in iter_txt_files(docs_dir):
        try:
            text = fp.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            text = fp.read_text(encoding="latin-1", errors="ignore")
        stat = fp.stat()
        writer.update_document(
            path=str(fp.resolve()),
            name=fp.stem,
            content=text,
            size=stat.st_size,
            mtime=int(stat.st_mtime)
        )
        count += 1
    writer.commit()
    elapsed = time.perf_counter() - start

    report = {
        "docs_dir": str(docs_dir.resolve()),
        "index_dir": str(index_dir.resolve()),
        "num_indexed": count,
        "elapsed_sec": round(elapsed, 4),
        "avg_ms_per_doc": round(1000 * elapsed / count, 3) if count else None
    }
    with open(index_dir / "report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    return count, elapsed


# ---------- RICERCA INTERATTIVA ----------

BANNER = (
    "Sintassi:\n"
    "  nome <termini ...>          — cerca nel nome del file\n"
    "  contenuto <termini ...>     — cerca nel contenuto del file\n"
    "  Usa virgolette per 'phrase query'.\n"
    "  Operatori supportati: AND, OR, NOT, ().\n"
    "  :help  mostra aiuto,  :quit esce.\n"
)

def choose_parser(ix, field: str) -> QueryParser:
    return QueryParser(field, ix.schema, group=OrGroup)

def run_search_repl(index_path: Path, topk: int = 10) -> None:
    """Interfaccia per eseguire query sull'indice."""
    if not index.exists_in(index_path):
        print(f"[ERRORE] Nessun indice in {index_path}. Esegui prima 'index'.")
        return
    ix = index.open_dir(index_path)
    frag = ContextFragmenter(maxchars=130, surround=40)
    fmt = UppercaseFormatter()

    print("== Ricerca nell'indice ==")
    print(BANNER)
    with ix.searcher() as s:
        while True:
            try:
                raw = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not raw:
                continue
            if raw in (":q", ":quit", ":exit"):
                break
            if raw in (":h", ":help"):
                print(BANNER)
                continue

            parts = raw.split(maxsplit=1)
            if len(parts) == 1:
                print("Usa: nome ...  oppure  contenuto ...")
                continue
            head, body = parts[0].lower(), parts[1].strip()
            if head not in ("nome", "contenuto"):
                print("Campo non valido. Usa 'nome' o 'contenuto'.")
                continue
            field = "name" if head == "nome" else "content"

            qp = choose_parser(ix, field)
            try:
                q = qp.parse(body)
            except Exception as e:
                print(f"[ERRORE QUERY] {e}")
                continue

            t0 = time.perf_counter()
            results = s.search(q, limit=topk)
            results.fragmenter = frag
            results.formatter = fmt
            dt = (time.perf_counter() - t0) * 1000.0

            print(f"\n{len(results)} risultati — {dt:.1f} ms — campo: {field}")
            for i, hit in enumerate(results):
                name = hit["name"]
                path = hit["path"]
                size = hit.get("size", "?")
                print(f"#{i+1}  {name}   [score={hit.score:.4f}, bytes={size}]")
                snippet = hit.highlights("content") or hit.highlights("name")
                if snippet:
                    print("   ", snippet.replace("\n", " "))
                print("    ", path)
            print()


# ---------- CLI PRINCIPALE ----------

def main():
    parser = argparse.ArgumentParser(description="Indicizzatore & motore di ricerca su .txt (Whoosh).")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_index = sub.add_parser("index", help="Indicizza una directory di .txt")
    p_index.add_argument("--docs", type=Path, required=True, help="Directory con i .txt")
    p_index.add_argument("--index", type=Path, required=True, help="Directory dove salvare l'indice")

    p_search = sub.add_parser("search", help="Avvia la ricerca interattiva")
    p_search.add_argument("--index", type=Path, required=True, help="Directory indice")
    p_search.add_argument("--topk", type=int, default=10, help="Numero di risultati (default 10)")

    args = parser.parse_args()
    if args.cmd == "index":
        if not args.docs.exists():
            print(f"[ERRORE] Directory non trovata: {args.docs}", file=sys.stderr)
            sys.exit(2)
        n, sec = index_dir(args.docs, args.index)
        print(f"Indicizzati {n} file in {sec:.2f}s ({(1000*sec/n):.1f} ms/doc)" if n else "Nessun .txt trovato")
        print(f"Report: {args.index / 'report.json'}")
    elif args.cmd == "search":
        run_search_repl(args.index, args.topk)


if __name__ == "__main__":
    main()